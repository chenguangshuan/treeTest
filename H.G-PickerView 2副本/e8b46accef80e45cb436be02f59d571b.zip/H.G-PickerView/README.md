BKDateAndTimePickerView
=======================

Custom date and time are separately provided in ios sdk with this 
control you can select both at the same time

Works on iOS 6+

LICENSE
=======================

Distributed under the MIT License.

Contributions
=======================

Any contribution is more than welcome! You can contribute through pull requests and issues on GitHub.

Author
=======================

Contact me on my email: mr.bhavya.kothari@gmail.com
