//  练手
//
//  Created by H.G on 16/1/12.
//  Copyright © 2016年 H.G. All rights reserved.
//  QQ交流:297505427
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
